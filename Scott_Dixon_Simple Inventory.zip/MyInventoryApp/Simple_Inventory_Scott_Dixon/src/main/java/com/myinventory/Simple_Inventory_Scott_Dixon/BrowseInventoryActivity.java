package com.myinventory.Simple_Inventory_Scott_Dixon;

import static com.myinventory.myinventoryapp.R.*;
import static com.myinventory.myinventoryapp.R.id.*;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.myinventory.myinventoryapp.R;

import java.util.ArrayList;
import java.util.Objects;

public class BrowseInventoryActivity extends AppCompatActivity implements SearchView.OnQueryTextListener{

    SearchView searchView;

    // recycler view to replace list view
    RecyclerView recyclerView;
    ItemDBHelper itemDB;

    ArrayList<String> item_id, item_name, item_price, item_quantity;

    RecyclerDisplayHome disadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_browse_inventory);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Browse Inventory");

        searchView=findViewById(id.searchView);
        searchView.clearFocus();



        // recyclerView replaces listView
        recyclerView = findViewById(recyclerView_browse);

        // database object
        itemDB = new ItemDBHelper(BrowseInventoryActivity.this);
        item_id = new ArrayList<>();
        item_name = new ArrayList<>();
        item_price = new ArrayList<>();
        item_quantity = new ArrayList<>();

        // call method to display data
        displayArrayData();

        disadapter = new RecyclerDisplayHome(BrowseInventoryActivity.this, this, item_id, item_name, item_price, item_quantity);
        // set array adapter
        recyclerView.setAdapter(disadapter);
        // get layout for the recycler view
        recyclerView.setLayoutManager((new LinearLayoutManager(BrowseInventoryActivity.this)));


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1){
            recreate();
        }
    }

    // method for data display
    void displayArrayData(){
        Cursor cursor = itemDB.readAllData();
        if (cursor.getCount() == 0){
            Toast.makeText(this, "No data to display", Toast.LENGTH_SHORT).show();
        }
        else{
            while (cursor.moveToNext()){
                item_id.add(cursor.getString(0));
                item_name.add(cursor.getString(1));
                item_price.add(cursor.getString(2));
                item_quantity.add(cursor.getString(3));
            }
        }
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if (item.getItemId() == add_button) {
            Intent BrowseInventoryActivity = new Intent(BrowseInventoryActivity.this, AddInventoryActivity.class);
            BrowseInventoryActivity.this.startActivity(BrowseInventoryActivity);
        }


        return super.onOptionsItemSelected(item);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.your_menu_resource, menu);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String s) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String s) {
        return false;
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }
}