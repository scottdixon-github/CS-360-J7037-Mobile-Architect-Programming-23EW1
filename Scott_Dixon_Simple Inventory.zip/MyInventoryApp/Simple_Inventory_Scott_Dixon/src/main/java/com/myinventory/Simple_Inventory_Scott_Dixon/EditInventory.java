package com.myinventory.Simple_Inventory_Scott_Dixon;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.myinventory.myinventoryapp.R;

public class EditInventory extends AppCompatActivity {
    EditText name_input, price_input, quantity_input;
    Button update_item_button;
    Button delete_button;
    String id, name, price, quantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_inventory);

        name_input = findViewById(R.id.update_add_item_name);
        price_input = findViewById(R.id.update_add_item_price);
        quantity_input = findViewById(R.id.update_add_item_quantity);
        update_item_button = findViewById(R.id.update_item_button);
        delete_button = findViewById(R.id.delete_button);

        // call get intent data
        getIntentData();

        // update button listener
        update_item_button.setOnClickListener((view) ->  {
            name = name_input.getText().toString().trim();
            price = price_input.getText().toString().trim();
            quantity = quantity_input.getText().toString().trim();
            if (name.equals("") || price.equals("") || quantity.equals("")) {
                Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
            }
            else{
                ItemDBHelper itemDB = new ItemDBHelper(EditInventory.this);
                itemDB.updateData(id, name, price, quantity);
                finish();
            }
        });

        // delete button
        delete_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // class to delete an item.
                confirmDialog();
            }
        });

        // set the name of the activity with the name of the inventory item
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setTitle(name);
        }
    }
        void getIntentData(){
            if(getIntent().hasExtra("id") &&
                    getIntent().hasExtra("name") &&
                    getIntent().hasExtra("price") &&
                    getIntent().hasExtra("quantity")){
                // get intent data
                id = getIntent().getStringExtra("id");
                name = getIntent().getStringExtra("name");
                price = getIntent().getStringExtra("price");
                quantity = getIntent().getStringExtra("quantity");

                // set the data from the intent
                name_input.setText(name);
                price_input.setText(price);
                quantity_input.setText(quantity);
            }
            else{
                Toast.makeText(this, "No data exists", Toast.LENGTH_SHORT).show();
            }
        }

        // dialog box to prompt user to delete
        void confirmDialog(){
            // create builder object
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            // display item name to be deleted
            builder.setTitle("Delete " + name + " ?");
            // ask if the user is sure they want to delete item name
            builder.setMessage("Are you sure you want to delete " + name + " ?");
            // display button to confirm yes
            builder.setPositiveButton("Yes", (dialogInterface, i) -> {
                // create database helper
                ItemDBHelper itemDB = new ItemDBHelper(EditInventory.this);
                // delete item from database
                itemDB.deleteOneRow(id);
                finish();
            });
            builder.setNegativeButton("No", (dialogInterface, i) -> {

            });
            builder.create().show();
        }
}

