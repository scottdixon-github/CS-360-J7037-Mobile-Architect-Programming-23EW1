package com.myinventory.Simple_Inventory_Scott_Dixon;

public class EnterPhoneActivity {
}

// not used yet but will implement with sms items sent or some other information
