package com.myinventory.Simple_Inventory_Scott_Dixon;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class sqliteOpen extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db";
    public sqliteOpen(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }
    // insert username and password
    public Boolean insertData(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        // insert the data
        long result = MyDB.insert("users", null, contentValues);
        // if insertion is not possible, return failure
        // insertion was successful
        return result != -1;
    }

    // check to see if username already exists
    public Boolean checkusername(String username) {
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from users where username = ?", new String[]{username});
        // username already exists
        // username does exist
        return cursor.getCount() > 0;
    }

    // double check if username and password already exist
    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        // username and password already exist
        // username and password do not exist
        return cursor.getCount() > 0;
    }
}