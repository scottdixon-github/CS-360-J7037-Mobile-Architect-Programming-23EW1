package com.myinventory.Simple_Inventory_Scott_Dixon;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.myinventory.myinventoryapp.R;

public class MainActivity extends AppCompatActivity {

    private static final int PERMISSION_SMS = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button browseBtn = findViewById(R.id.browseBtn);
        Button addBtn = findViewById(R.id.addBtn);
        Button addphonebtn = findViewById(R.id.addphonebtn);
        Button logoutBtn = findViewById(R.id.logoutBtn);

        browseBtn.setOnClickListener(view -> {
            Intent browseInventoryIntent = new Intent(MainActivity.this, BrowseInventoryActivity.class);
            startActivity(browseInventoryIntent);
        });


        addBtn.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent BrowseInventoryActivity = new Intent(MainActivity.this, AddInventoryActivity.class);
                MainActivity.this.startActivity(BrowseInventoryActivity);
            }
        }));


        addphonebtn.setOnClickListener(this::onClick);

        logoutBtn.setOnClickListener(view -> {
            // Handle logout logic here (e.g., clear session, go to login screen, etc.)
            Intent loginIntent = new Intent(MainActivity.this, LoginActivity.class);
            loginIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(loginIntent);
            finish(); // Close the current activity
        });
    }

    private boolean checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                //message request the permission for sms
                new AlertDialog.Builder(this)
                        .setMessage("We need permission to send SMS for low inventory notifications.")
                        .setPositiveButton("Allow", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SMS);
                            }
                        })
                        .setNegativeButton("Deny", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                // Handle the user's decision (e.g., show a message)
                            }
                        })
                        // add logic that displays status of permission?
                        .create()
                        .show();
                return false; // Permission not granted
            } else {
                // Request the permission without explanation
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SMS);
                return false; // Permission not granted
            }
        }
        return true; // Permission already granted
    }
    // I need to add logic that returns low inventory amount based on certain criteria (Item < 2?)
    private void sendLowInventoryNotification() {
            String phoneNumber = "3129567549"; // my phone number
            String message = "Low inventory alert: Your item is running low!"; //notification

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } catch (Exception e) {
                e.printStackTrace();

            }
        }

    private void onClick(View view) {
        // Check for SMS permission before sending SMS
        if (checkSmsPermission()) {
            // Send SMS notification
            sendLowInventoryNotification();
        } else {
            // Handle the case when the user denied SMS permission (e.g., show a message)
        }
    }
}

