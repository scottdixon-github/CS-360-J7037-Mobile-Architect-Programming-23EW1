package com.myinventory.Simple_Inventory_Scott_Dixon;

public class LoginActivity {
}
